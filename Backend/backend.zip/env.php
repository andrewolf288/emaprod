; <?php exit; ?>

<!-- MYSQL_DATABASE_NAME = "emaprod6" -->
MYSQL_DATABASE_NAME = "emaprod_dev"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""