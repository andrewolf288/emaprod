<?php
// EN ESTE SCRIPT DEBE ESTAR LA OPERACION DE REGISTRO
// TIPO: INTEGRACION
/*
    1. EN EL SISTEMA EMAFACT SE REALIZA UNA OPERACION DE NOTA DE CREDITO
    2. AQUELLAS QUE SON DEL TIPO DE MOTIVO CORRESPONDIENTE SON DE NUESTRO INTERES
    (devolucion total, anulacion de pedido, devolucion parcial)
    3. SE COMUNICA CON EL SISTEMA EMAPROD Y CREA EL REGISTRO CORRESPONDIENTE
*/

include_once "../../common/cors.php";
header('Content-Type: application/json; charset=utf-8');
require('../../common/conexion.php');

$pdo = getPDO();
$message_error = "";
$description_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    $idRefGui = intVal($data["idRefGui"]); // id de la guia de remision
    $idCredNot = $data["idCredNot"]; // id de la nota decredito
    $idMot = intVal($data["idMot"]); // motivo
    $invoice_serie = $data["invoice_serie"]; // serie
    $invoice_number = $data["invoice_number"]; // numero
    $items = $data["items"]; // items

    if ($pdo) {
    }

    // Retornamos el resultado
    $return['message_error'] = $message_error;
    $return['description_error'] = $description_error;
    echo json_encode($return);
}
