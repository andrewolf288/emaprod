<?php
function entradaProductoFinalTransferenciaAlmacen(){

}

function entradaMateriaPrimaMaterialesTransferenciaAlmacen(){
    
}