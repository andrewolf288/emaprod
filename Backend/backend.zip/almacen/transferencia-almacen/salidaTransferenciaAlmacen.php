<?php
function salidaProductoFinalTransferenciaAlmacen(){

}

function salidaMateriaPrimaMaterialesTransferenciaAlmacen(){
    
}